/**
 * Comment and entry pagers used in Admin/editor UI
 */
package org.apache.roller.weblogger.ui.struts2.pagers;