/*
 * Template.java
 *
 * Created on December 11, 2006, 3:09 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.apache.roller.planet.pojos;

/**
 *
 */
public interface Template {
    
    String getId();
    
    String getTemplateLanguage();
    
}
