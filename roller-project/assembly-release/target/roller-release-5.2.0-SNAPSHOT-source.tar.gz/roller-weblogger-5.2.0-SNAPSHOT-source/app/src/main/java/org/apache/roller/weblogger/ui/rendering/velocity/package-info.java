/**
 * Velocity renderer and supporting classes.
 */
package org.apache.roller.weblogger.ui.rendering.velocity;