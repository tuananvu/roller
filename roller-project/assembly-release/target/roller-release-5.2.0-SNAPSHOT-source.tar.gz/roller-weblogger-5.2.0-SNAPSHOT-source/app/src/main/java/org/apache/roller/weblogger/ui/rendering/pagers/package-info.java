/**
 * Pager objects for use in Roller page/feed templates.
 */
package org.apache.roller.weblogger.ui.rendering.pagers;