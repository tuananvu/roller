/**
 * Page, feed, site and feed caches.
 */
package org.apache.roller.weblogger.ui.rendering.util.cache;