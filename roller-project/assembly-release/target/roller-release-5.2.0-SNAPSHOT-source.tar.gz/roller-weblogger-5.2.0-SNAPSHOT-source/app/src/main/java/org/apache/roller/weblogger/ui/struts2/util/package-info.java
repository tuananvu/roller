/**
 * Struts 2 utility and base classes used in editor/admin UI.
 */
package org.apache.roller.weblogger.ui.struts2.util;