/**
 * Comment validators, request wrappers and other rendering utilities.
 */
package org.apache.roller.weblogger.ui.rendering.util;