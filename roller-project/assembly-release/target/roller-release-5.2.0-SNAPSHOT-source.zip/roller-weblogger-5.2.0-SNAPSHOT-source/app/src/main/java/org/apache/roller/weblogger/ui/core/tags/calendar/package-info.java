/**
 * JSP tag for displaying weblog calendar
 */
package org.apache.roller.weblogger.ui.core.tags.calendar;