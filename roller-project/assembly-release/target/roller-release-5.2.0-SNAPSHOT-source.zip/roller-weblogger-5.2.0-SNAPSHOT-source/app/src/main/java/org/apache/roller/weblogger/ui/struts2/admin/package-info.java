/**
 * Struts 2 actions for admin UI
 */
package org.apache.roller.weblogger.ui.struts2.admin;