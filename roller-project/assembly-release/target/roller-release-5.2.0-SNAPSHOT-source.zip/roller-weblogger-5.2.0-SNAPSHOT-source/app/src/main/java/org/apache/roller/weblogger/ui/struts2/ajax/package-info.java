/**
 * Returns data in simple formats for use in AJAX
 */
package org.apache.roller.weblogger.ui.struts2.ajax;