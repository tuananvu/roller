/**
 * Comment validators and authenticators.
 */
package org.apache.roller.weblogger.ui.rendering.plugins.comments;